import Header from "./components/Header";
import Nav from "./components/Nav";
import Search from "./components/Search";
import Card from "./components/Card";
import About from "./components/About";
import Info from "./components/Info";
import OnDemand from "./components/OnDemand";
import Hotels from "./components/Hotels";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import Subscribe from "./components/Subscribe";

function App() {
  return (
    <>
      <Nav />
      <Header title="Doble size bed" />
      <div className="w3-content" style={{ maxWidth: 1532 + "px" }}>
        <div className="w3-container w3-margin-top" id="rooms">
          <h3>Rooms</h3>
          <p>
            Make yourself at home is our slogan. We offer the best beds in the
            industry. Sleep well and rest well.
          </p>
        </div>
        <Search />
        <div className="w3-row-padding w3-padding-16">
          <Card
            imageUrl="https://www.w3schools.com/w3images/room_single.jpg"
            title="Single Room"
            price="99"
            bedType="Single bed"
            size="15"
            services={[
              <i class="fa fa-bath"></i>,
              <i class="fa fa-phone"></i>,
              <i class="fa fa-wifi"></i>,
            ]}
          />
          <Card
            imageUrl="https://www.w3schools.com/w3images/room_double.jpg"
            title="Double Room"
            price="149"
            bedType="Queen-size bed"
            size="25"
            services={[
              <i class="fa fa-bath"></i>,
              <i class="fa fa-phone"></i>,
              <i class="fa fa-wifi"></i>,
              <i class="fa fa-tv"></i>,
            ]}
          />
          <Card
            imageUrl="https://www.w3schools.com/w3images/room_deluxe.jpg"
            title="Deluxe Room"
            price="199"
            bedType="King-size bed"
            size="40"
            services={[
              <i class="fa fa-bath"></i>,
              <i class="fa fa-phone"></i>,
              <i class="fa fa-wifi"></i>,
              <i class="fa fa-tv"></i>,
              <i class="fa fa-glass"></i>,
              <i class="fa fa-cutlery"></i>,
            ]}
          />
        </div>
        <About />
        <Info />
        <OnDemand />
        <Hotels />
        <Contact />
        <Subscribe />
      </div>
      <Footer />
    </>
  );
}

export default App;
