function OnDemand() {
  return (
    <div className="w3-panel w3-red w3-leftbar w3-padding-32">
      <h6>
        <i className="fa fa-info w3-deep-orange w3-padding w3-margin-right" />
        On demand, we can offer playstation, babycall, children care, dog
        equipment, etc.
      </h6>
    </div>
  );
}
export default OnDemand;
