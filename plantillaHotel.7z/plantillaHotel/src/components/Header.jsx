import Form from "./Form";

function Header() {
  return (
    <header
      className="w3-display-container w3-content"
      style={{ maxWidth: 1500 }}
    >
      <img
        className="w3-image"
        src="https://www.w3schools.com/w3images/hotel.jpg"
        alt="The Hotel"
        style={{ minWidth: 1000 }}
        width={1500}
        height={800}
      />
      <Form />
    </header>
  );
}
export default Header;
