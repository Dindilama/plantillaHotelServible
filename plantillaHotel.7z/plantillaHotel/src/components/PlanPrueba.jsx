function PlanPrueba() {
  return;
}
export default PlanPrueba;
