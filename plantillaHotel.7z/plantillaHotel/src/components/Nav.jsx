function Nav() {
  return (
    <div className="w3-bar w3-white w3-large">
      <a href="/" className="w3-bar-item w3-button w3-red w3-mobile">
        <i className="fa fa-bed w3-margin-right"></i>Logo
      </a>
      <a href="/rooms" className="w3-bar-item w3-button w3-mobile">
        Rooms
      </a>
      <a href="/our-company" className="w3-bar-item w3-button w3-mobile">
        Our Company
      </a>
      <a href="/tourist-plans" className="w3-bar-item w3-button w3-mobile">
        Tourist plans
      </a>
      <a
        href="#contact"
        className="w3-bar-item w3-button w3-right w3-light-grey w3-mobile"
      >
        Book Now
      </a>
      <a
        href="#prueba"
        className="w3-bar-item w3-button w3-right w3-light-grey w3-mobile"
      >
        Plan prueba
      </a>
    </div>
  );
}

export default Nav;
