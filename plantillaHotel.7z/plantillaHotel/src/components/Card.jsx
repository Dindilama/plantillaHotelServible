function Card({ imageUrl, title, price, bedType, size, services }) {
  return (
    <div className="w3-third w3-margin-bottom">
      <img src={imageUrl} alt="Norway" style={{ width: 100 + "%" }} />
      <div className="w3-container w3-white">
        <h3>{title}</h3>
        <h6 className="w3-opacity">From ${price}</h6>
        <p>{bedType}</p>
        <p>
          {size}m<sup>2</sup>
        </p>
        <p className="w3-large">{services}</p>
        <button className="w3-button w3-block w3-black w3-margin-bottom">
          Choose Room
        </button>
      </div>
    </div>
  );
}

export default Card;
